import { useState } from "react";

export default function Profile() {
  const [activeTab, setActiveTab] = useState("overview");
  const [depositAmount, setDepositAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("bank");

  // Mock user data - in real app, this would come from API
  const userData = {
    name: "Nguyễn Văn An",
    email: "nguyenvanan@email.com",
    phone: "0901234567",
    balance: "125,450,000",
    totalInvested: "500,000,000",
    totalProfit: "45,750,000",
    joinDate: "2024-03-15",
    kycStatus: "verified",
    investments: [
      { id: 1, fundName: "DC 60kW Charging Station", amount: "50,000,000", profit: "5,250,000", status: "active" },
      { id: 2, fundName: "VIC Premium Fast Charge", amount: "100,000,000", profit: "18,500,000", status: "active" },
      { id: 3, fundName: "VIC Ultimate Network", amount: "200,000,000", profit: "22,000,000", status: "completed" },
      { id: 4, fundName: "VIC Future Tech Station", amount: "150,000,000", profit: "0", status: "pending" }
    ],
    transactions: [
      { id: 1, type: "deposit", amount: "50,000,000", date: "2025-01-25", status: "completed", method: "Chuyển khoản" },
      { id: 2, type: "investment", amount: "-100,000,000", date: "2025-01-24", status: "completed", method: "VIC Premium" },
      { id: 3, type: "profit", amount: "+2,150,000", date: "2025-01-23", status: "completed", method: "Lợi nhuận hàng ngày" },
      { id: 4, type: "withdraw", amount: "-25,000,000", date: "2025-01-22", status: "completed", method: "Rút về ngân hàng" }
    ]
  };

  const paymentMethods = [
    { id: "bank", name: "Chuyển khoản ngân hàng", icon: "fas fa-building-columns", fee: "0%" },
    { id: "momo", name: "Ví MoMo", icon: "fas fa-mobile-alt", fee: "1%" },
    { id: "zalopay", name: "ZaloPay", icon: "fas fa-wallet", fee: "1%" },
    { id: "viettel", name: "ViettelPay", icon: "fas fa-phone", fee: "1.5%" }
  ];

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Nạp ${depositAmount} VNĐ thành công!`);
    setDepositAmount("");
  };

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Rút ${withdrawAmount} VNĐ thành công!`);
    setWithdrawAmount("");
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit": return "fas fa-arrow-down text-green-600";
      case "withdraw": return "fas fa-arrow-up text-red-600";
      case "investment": return "fas fa-chart-line text-blue-600";
      case "profit": return "fas fa-plus text-green-600";
      default: return "fas fa-exchange-alt text-gray-600";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800";
      case "completed": return "bg-blue-100 text-blue-800";
      case "pending": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-vgreen-primary to-vgreen-accent text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center">
            <div className="w-20 h-20 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-6">
              <i className="fas fa-user text-3xl"></i>
            </div>
            <div>
              <h1 className="text-3xl font-bold font-sans mb-2">{userData.name}</h1>
              <p className="text-gray-200 font-sans">Thành viên từ {new Date(userData.joinDate).toLocaleDateString('vi-VN')}</p>
              <div className="flex items-center mt-2">
                <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium mr-3">
                  <i className="fas fa-check-circle mr-1"></i>
                  Đã xác thực KYC
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Balance Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Số dư khả dụng</h3>
              <i className="fas fa-wallet text-vgreen-primary text-xl"></i>
            </div>
            <div className="text-3xl font-bold text-vgreen-primary mb-2">{userData.balance} VNĐ</div>
            <p className="text-sm text-gray-600">Có thể đầu tư hoặc rút</p>
          </div>
          
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Tổng đã đầu tư</h3>
              <i className="fas fa-chart-line text-blue-600 text-xl"></i>
            </div>
            <div className="text-3xl font-bold text-blue-600 mb-2">{userData.totalInvested} VNĐ</div>
            <p className="text-sm text-gray-600">Trong các quỹ đầu tư</p>
          </div>
          
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Tổng lợi nhuận</h3>
              <i className="fas fa-coins text-green-600 text-xl"></i>
            </div>
            <div className="text-3xl font-bold text-green-600 mb-2">+{userData.totalProfit} VNĐ</div>
            <p className="text-sm text-gray-600">Lợi nhuận tích lũy</p>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Tabs */}
          <div className="border-b border-gray-200">
            <div className="flex overflow-x-auto">
              {[
                { id: "overview", name: "Tổng quan", icon: "fas fa-chart-pie" },
                { id: "deposit", name: "Nạp tiền", icon: "fas fa-arrow-down" },
                { id: "withdraw", name: "Rút tiền", icon: "fas fa-arrow-up" },
                { id: "investments", name: "Đầu tư", icon: "fas fa-chart-line" },
                { id: "transactions", name: "Giao dịch", icon: "fas fa-history" },
                { id: "settings", name: "Cài đặt", icon: "fas fa-cog" }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-6 py-4 font-medium whitespace-nowrap ${
                    activeTab === tab.id
                      ? "border-b-2 border-vgreen-primary text-vgreen-primary"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <i className={`${tab.icon} mr-2`}></i>
                  {tab.name}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="p-8">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div className="space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-6">Thông tin cá nhân</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Họ và tên</label>
                      <div className="text-lg font-semibold text-gray-900">{userData.name}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <div className="text-lg font-semibold text-gray-900">{userData.email}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Số điện thoại</label>
                      <div className="text-lg font-semibold text-gray-900">{userData.phone}</div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Trạng thái KYC</label>
                      <span className="inline-flex items-center bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                        <i className="fas fa-check-circle mr-1"></i>
                        Đã xác thực
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-6">Thống kê đầu tư</h3>
                  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-blue-50 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-blue-600">{userData.investments.length}</div>
                      <div className="text-sm text-gray-600">Quỹ đang tham gia</div>
                    </div>
                    <div className="bg-green-50 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {userData.investments.filter(inv => inv.status === 'active').length}
                      </div>
                      <div className="text-sm text-gray-600">Đầu tư đang hoạt động</div>
                    </div>
                    <div className="bg-yellow-50 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-yellow-600">
                        {userData.investments.filter(inv => inv.status === 'pending').length}
                      </div>
                      <div className="text-sm text-gray-600">Đang chờ xử lý</div>
                    </div>
                    <div className="bg-purple-50 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-purple-600">9.15%</div>
                      <div className="text-sm text-gray-600">ROI trung bình</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Deposit Tab */}
            {activeTab === "deposit" && (
              <div className="max-w-2xl mx-auto space-y-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Nạp tiền vào tài khoản</h3>
                  <p className="text-gray-600">Chọn phương thức và nhập số tiền muốn nạp</p>
                </div>

                <form onSubmit={handleDeposit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-4">Chọn phương thức thanh toán</label>
                    <div className="grid md:grid-cols-2 gap-4">
                      {paymentMethods.map((method) => (
                        <div
                          key={method.id}
                          onClick={() => setSelectedPaymentMethod(method.id)}
                          className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                            selectedPaymentMethod === method.id
                              ? "border-vgreen-primary bg-green-50"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <i className={`${method.icon} text-xl mr-3`}></i>
                              <div>
                                <div className="font-semibold">{method.name}</div>
                                <div className="text-sm text-gray-600">Phí: {method.fee}</div>
                              </div>
                            </div>
                            {selectedPaymentMethod === method.id && (
                              <i className="fas fa-check-circle text-vgreen-primary"></i>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Số tiền nạp (VNĐ)</label>
                    <input
                      type="text"
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-vgreen-primary focus:border-transparent"
                      placeholder="Nhập số tiền muốn nạp"
                      required
                    />
                    <div className="flex gap-2 mt-2">
                      {["1,000,000", "5,000,000", "10,000,000", "50,000,000"].map((amount) => (
                        <button
                          key={amount}
                          type="button"
                          onClick={() => setDepositAmount(amount)}
                          className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200 transition-colors"
                        >
                          {amount}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-vgreen-primary to-success text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
                  >
                    <i className="fas fa-arrow-down mr-2"></i>
                    Nạp tiền
                  </button>
                </form>
              </div>
            )}

            {/* Withdraw Tab */}
            {activeTab === "withdraw" && (
              <div className="max-w-2xl mx-auto space-y-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Rút tiền về ngân hàng</h3>
                  <p className="text-gray-600">Số dư khả dụng: <span className="font-bold text-vgreen-primary">{userData.balance} VNĐ</span></p>
                </div>

                <form onSubmit={handleWithdraw} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Số tiền rút (VNĐ)</label>
                    <input
                      type="text"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-vgreen-primary focus:border-transparent"
                      placeholder="Nhập số tiền muốn rút"
                      required
                    />
                    <div className="flex gap-2 mt-2">
                      {["1,000,000", "5,000,000", "10,000,000", "Tất cả"].map((amount) => (
                        <button
                          key={amount}
                          type="button"
                          onClick={() => setWithdrawAmount(amount === "Tất cả" ? userData.balance : amount)}
                          className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm hover:bg-gray-200 transition-colors"
                        >
                          {amount}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h4 className="font-semibold text-yellow-800 mb-2">Lưu ý về phí rút tiền:</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Rút thường (1-3 ngày): Phí 0.5%</li>
                      <li>• Rút nhanh (trong ngày): Phí 2%</li>
                      <li>• Số tiền tối thiểu: 100,000 VNĐ</li>
                    </ul>
                  </div>

                  <div className="flex gap-4">
                    <button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-vgreen-primary to-success text-white py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
                    >
                      <i className="fas fa-arrow-up mr-2"></i>
                      Rút thường (0.5%)
                    </button>
                    <button
                      type="button"
                      className="flex-1 bg-orange-600 text-white py-3 rounded-lg font-semibold hover:bg-orange-700 transition-colors"
                    >
                      <i className="fas fa-bolt mr-2"></i>
                      Rút nhanh (2%)
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Investments Tab */}
            {activeTab === "investments" && (
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-6">Danh sách đầu tư</h3>
                <div className="space-y-4">
                  {userData.investments.map((investment) => (
                    <div key={investment.id} className="bg-gray-50 rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-lg font-semibold text-gray-900">{investment.fundName}</h4>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(investment.status)}`}>
                          {investment.status === 'active' ? 'Đang hoạt động' : 
                           investment.status === 'completed' ? 'Hoàn thành' : 'Chờ xử lý'}
                        </span>
                      </div>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <div className="text-sm text-gray-600 mb-1">Số tiền đầu tư</div>
                          <div className="text-lg font-bold text-blue-600">{investment.amount} VNĐ</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600 mb-1">Lợi nhuận</div>
                          <div className="text-lg font-bold text-green-600">+{investment.profit} VNĐ</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600 mb-1">ROI</div>
                          <div className="text-lg font-bold text-purple-600">
                            {investment.profit !== "0" ? 
                              ((parseInt(investment.profit.replace(/,/g, "")) / parseInt(investment.amount.replace(/,/g, ""))) * 100).toFixed(2) + "%" 
                              : "0%"}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Transactions Tab */}
            {activeTab === "transactions" && (
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-6">Lịch sử giao dịch</h3>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Loại</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Số tiền</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phương thức</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ngày</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trạng thái</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {userData.transactions.map((transaction) => (
                        <tr key={transaction.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <i className={`${getTransactionIcon(transaction.type)} mr-3`}></i>
                              <span className="capitalize">
                                {transaction.type === 'deposit' ? 'Nạp tiền' :
                                 transaction.type === 'withdraw' ? 'Rút tiền' :
                                 transaction.type === 'investment' ? 'Đầu tư' :
                                 'Lợi nhuận'}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`font-semibold ${
                              transaction.amount.startsWith('+') ? 'text-green-600' : 
                              transaction.amount.startsWith('-') ? 'text-red-600' : 'text-gray-900'
                            }`}>
                              {transaction.amount} VNĐ
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {transaction.method}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(transaction.date).toLocaleDateString('vi-VN')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                              Hoàn thành
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Settings Tab */}
            {activeTab === "settings" && (
              <div className="max-w-2xl mx-auto space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-6">Cài đặt tài khoản</h3>
                  
                  <div className="space-y-6">
                    <div className="bg-gray-50 rounded-lg p-6">
                      <h4 className="font-semibold text-gray-900 mb-4">Bảo mật</h4>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">Xác thực 2 lớp (2FA)</div>
                            <div className="text-sm text-gray-600">Tăng cường bảo mật cho tài khoản</div>
                          </div>
                          <button className="bg-vgreen-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-vgreen-secondary transition-colors">
                            Kích hoạt
                          </button>
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">Đổi mật khẩu</div>
                            <div className="text-sm text-gray-600">Cập nhật mật khẩu định kỳ</div>
                          </div>
                          <button className="bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-700 transition-colors">
                            Đổi mật khẩu
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-50 rounded-lg p-6">
                      <h4 className="font-semibold text-gray-900 mb-4">Thông báo</h4>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">Email thông báo</div>
                            <div className="text-sm text-gray-600">Nhận thông báo qua email</div>
                          </div>
                          <input type="checkbox" className="toggle" defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">SMS thông báo</div>
                            <div className="text-sm text-gray-600">Nhận thông báo qua SMS</div>
                          </div>
                          <input type="checkbox" className="toggle" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom padding for mobile navigation */}
      <div className="pb-20 md:pb-0"></div>
    </div>
  );
}