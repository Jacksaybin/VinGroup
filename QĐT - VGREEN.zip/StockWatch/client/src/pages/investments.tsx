import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type InvestmentFund } from "@shared/schema";
import InvestmentModal from "@/components/InvestmentModal";

export default function Investments() {
  const [selectedCategory, setSelectedCategory] = useState<string>("Tất Cả");
  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");
  const [selectedFund, setSelectedFund] = useState<InvestmentFund | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const { data: funds = [], isLoading } = useQuery<InvestmentFund[]>({
    queryKey: ["/api/investment-funds"],
  });

  const categories = ["Tất Cả", "Cơ Bản", "Đặc Biệt", "Thường", "VIP", "Cao Cấp", "Premium", "VIC", "VIC Premium", "VIC Elite", "VIC Ultimate", "VIC Future"];

  const filteredFunds = selectedCategory === "Tất Cả" 
    ? funds 
    : funds.filter(fund => fund.category === selectedCategory);

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "Cơ Bản": "bg-blue-100 text-blue-800",
      "Đặc Biệt": "bg-purple-100 text-purple-800",
      "Thường": "bg-green-100 text-green-800",
      "VIP": "bg-yellow-100 text-yellow-800",
      "Cao Cấp": "bg-indigo-100 text-indigo-800",
      "Premium": "bg-pink-100 text-pink-800",
      "VIC": "bg-orange-100 text-orange-800",
      "VIC Premium": "bg-red-100 text-red-800",
      "VIC Elite": "bg-emerald-100 text-emerald-800",
      "VIC Ultimate": "bg-violet-100 text-violet-800",
      "VIC Future": "bg-rose-100 text-rose-800"
    };
    return colors[category] || "bg-gray-100 text-gray-800";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-vgreen-primary mx-auto"></div>
            <p className="mt-4 text-gray-600">Đang tải danh sách quỹ đầu tư...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-vgreen-primary to-vgreen-accent text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold font-sans mb-4">Quỹ Đầu Tư Trạm Sạc VinFast</h1>
            <p className="text-xl text-gray-200 font-sans">14 gói đầu tư với lợi nhuận từ 0.2% - 2.2% mỗi ngày</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Navigation and Filters */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-6">
            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    selectedCategory === category
                      ? "bg-vgreen-primary text-white"
                      : "bg-white text-gray-600 hover:text-vgreen-primary border border-gray-200"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* View Mode Toggle */}
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setViewMode("grid")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  viewMode === "grid"
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-500 hover:text-gray-900"
                }`}
              >
                <i className="fas fa-th-large mr-2"></i>
                Lưới
              </button>
              <button
                onClick={() => setViewMode("table")}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  viewMode === "table"
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-500 hover:text-gray-900"
                }`}
              >
                <i className="fas fa-table mr-2"></i>
                Bảng
              </button>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-lg p-4 text-center shadow-sm">
              <div className="text-2xl font-bold text-vgreen-primary">{filteredFunds.length}</div>
              <div className="text-sm text-gray-600">Quỹ Đầu Tư</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center shadow-sm">
              <div className="text-2xl font-bold text-blue-600">0.2% - 2.2%</div>
              <div className="text-sm text-gray-600">Lợi Nhuận/Ngày</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center shadow-sm">
              <div className="text-2xl font-bold text-green-600">30 - 365</div>
              <div className="text-sm text-gray-600">Ngày Đầu Tư</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center shadow-sm">
              <div className="text-2xl font-bold text-purple-600">50M+</div>
              <div className="text-sm text-gray-600">VNĐ Tối Thiểu</div>
            </div>
          </div>
        </div>

        {/* Grid View */}
        {viewMode === "grid" && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredFunds.map((fund) => (
              <div key={fund.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={fund.image} 
                    alt={fund.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-20"></div>
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(fund.category)}`}>
                      {fund.category}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4 bg-white bg-opacity-90 rounded-lg p-2">
                    <div className="text-lg font-bold text-vgreen-primary">{fund.code}</div>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{fund.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{fund.description}</p>

                  <div className="grid grid-cols-3 gap-3 mb-6">
                    <div className="text-center bg-green-50 rounded-lg p-3">
                      <div className="text-lg font-bold text-green-600">{fund.dailyReturn}%</div>
                      <div className="text-xs text-gray-600">Lợi nhuận/ngày</div>
                    </div>
                    <div className="text-center bg-blue-50 rounded-lg p-3">
                      <div className="text-lg font-bold text-blue-600">{fund.duration}</div>
                      <div className="text-xs text-gray-600">Ngày</div>
                    </div>
                    <div className="text-center bg-purple-50 rounded-lg p-3">
                      <div className="text-lg font-bold text-purple-600">{fund.progress}%</div>
                      <div className="text-xs text-gray-600">Hoàn thành</div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Quy mô dự án</span>
                      <span className="font-semibold">{fund.projectScale}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Tối thiểu</span>
                      <span className="font-semibold text-vgreen-primary">{fund.minInvestment}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <a 
                      href={`/fund/${fund.id}`}
                      className="flex-1 bg-white border-2 border-vgreen-primary text-vgreen-primary py-3 rounded-xl font-semibold hover:bg-vgreen-primary hover:text-white transition-all duration-300 text-center"
                    >
                      <i className="fas fa-eye mr-2"></i>
                      Xem Chi Tiết
                    </a>
                    <button 
                      onClick={() => {
                        setSelectedFund(fund);
                        setIsModalOpen(true);
                      }}
                      className="flex-1 bg-gradient-to-r from-vgreen-primary to-success text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300"
                    >
                      <i className="fas fa-plus mr-2"></i>
                      Đầu Tư
                    </button>
                  </div>

                  <div className="mt-4">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-vgreen-primary to-success h-2 rounded-full transition-all duration-300" 
                        style={{width: `${fund.progress}%`}}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Table View */}
        {viewMode === "table" && (
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-vgreen-primary to-success text-white">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-medium">Quỹ Đầu Tư</th>
                    <th className="px-6 py-4 text-left text-sm font-medium">Mã</th>
                    <th className="px-6 py-4 text-left text-sm font-medium">Lợi Nhuận/Ngày</th>
                    <th className="px-6 py-4 text-left text-sm font-medium">Thời Gian</th>
                    <th className="px-6 py-4 text-left text-sm font-medium">Tối Thiểu</th>
                    <th className="px-6 py-4 text-left text-sm font-medium">Tiến Độ</th>
                    <th className="px-6 py-4 text-left text-sm font-medium">Danh Mục</th>
                    <th className="px-6 py-4 text-left text-sm font-medium">Hành Động</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredFunds.map((fund) => (
                    <tr key={fund.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <img 
                            src={fund.image} 
                            alt={fund.name}
                            className="w-12 h-12 rounded-lg object-cover mr-4"
                          />
                          <div>
                            <div className="font-semibold text-gray-900">{fund.name}</div>
                            <div className="text-sm text-gray-600">{fund.projectScale}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="bg-vgreen-primary text-white px-2 py-1 rounded text-sm font-medium">
                          {fund.code}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-lg font-bold text-green-600">{fund.dailyReturn}%</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-gray-900">{fund.duration} ngày</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-semibold text-vgreen-primary">{fund.minInvestment}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-20 bg-gray-200 rounded-full h-2 mr-2">
                            <div 
                              className="bg-gradient-to-r from-vgreen-primary to-success h-2 rounded-full" 
                              style={{width: `${fund.progress}%`}}
                            ></div>
                          </div>
                          <span className="text-sm font-medium">{fund.progress}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(fund.category)}`}>
                          {fund.category}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex space-x-2">
                          <a 
                            href={`/fund/${fund.id}`}
                            className="bg-white border border-vgreen-primary text-vgreen-primary px-3 py-2 rounded-lg text-sm font-medium hover:bg-vgreen-primary hover:text-white transition-colors"
                          >
                            <i className="fas fa-eye mr-1"></i>
                            Chi Tiết
                          </a>
                          <button 
                            onClick={() => {
                              setSelectedFund(fund);
                              setIsModalOpen(true);
                            }}
                            className="bg-vgreen-primary text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-vgreen-secondary transition-colors"
                          >
                            <i className="fas fa-plus mr-1"></i>
                            Đầu Tư
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {filteredFunds.length === 0 && (
          <div className="text-center py-12">
            <i className="fas fa-search text-gray-400 text-4xl mb-4"></i>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Không tìm thấy quỹ đầu tư</h3>
            <p className="text-gray-600">Thử chọn danh mục khác hoặc xem tất cả các quỹ</p>
          </div>
        )}
      </div>

      {/* Bottom padding for mobile navigation */}
      <div className="pb-20 md:pb-0"></div>

      {/* Investment Modal */}
      {selectedFund && (
        <InvestmentModal
          fund={selectedFund}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setSelectedFund(null);
          }}
        />
      )}
    </div>
  );
}