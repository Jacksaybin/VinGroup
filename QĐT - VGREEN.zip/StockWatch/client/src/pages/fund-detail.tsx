import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { type InvestmentFund } from "@shared/schema";
import InvestmentModal from "@/components/InvestmentModal";

export default function FundDetail() {
  const { id } = useParams();
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const { data: fund, isLoading } = useQuery<InvestmentFund>({
    queryKey: ["/api/investment-funds", id],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-vgreen-primary mx-auto"></div>
            <p className="mt-4 text-gray-600">Đang tải thông tin quỹ đầu tư...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!fund) {
    return (
      <div className="min-h-screen bg-gray-50 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <i className="fas fa-exclamation-triangle text-yellow-500 text-6xl mb-4"></i>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Không tìm thấy quỹ đầu tư</h2>
          <p className="text-gray-600 mb-8">Quỹ đầu tư bạn tìm kiếm không tồn tại hoặc đã bị xóa.</p>
          <Link href="/investments" className="bg-vgreen-primary text-white px-6 py-3 rounded-lg font-semibold hover:bg-vgreen-secondary transition-colors">
            <i className="fas fa-arrow-left mr-2"></i>
            Quay lại danh sách quỹ
          </Link>
        </div>
      </div>
    );
  }

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "Cơ Bản": "bg-blue-100 text-blue-800",
      "Đặc Biệt": "bg-purple-100 text-purple-800",
      "Thường": "bg-green-100 text-green-800",
      "VIP": "bg-yellow-100 text-yellow-800",
      "Cao Cấp": "bg-indigo-100 text-indigo-800",
      "Premium": "bg-pink-100 text-pink-800",
      "VIC": "bg-orange-100 text-orange-800",
      "VIC Premium": "bg-red-100 text-red-800",
      "VIC Elite": "bg-emerald-100 text-emerald-800",
      "VIC Ultimate": "bg-violet-100 text-violet-800",
      "VIC Future": "bg-rose-100 text-rose-800"
    };
    return colors[category] || "bg-gray-100 text-gray-800";
  };

  const totalReturn = (parseFloat(fund.dailyReturn) * fund.duration).toFixed(1);
  const minInvestmentNum = parseInt(fund.minInvestment.replace(/[^\d]/g, ""));
  const maxInvestmentNum = fund.maxInvestment ? parseInt(fund.maxInvestment.replace(/[^\d]/g, "")) : null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="relative h-80 overflow-hidden">
        <img 
          src={fund.image} 
          alt={fund.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
            <div className="text-white">
              <div className="flex items-center space-x-4 mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(fund.category)} bg-opacity-90`}>
                  {fund.category}
                </span>
                <span className="bg-white bg-opacity-20 px-3 py-1 rounded-lg text-sm font-bold">
                  {fund.code}
                </span>
              </div>
              <h1 className="text-4xl font-bold font-sans mb-4">{fund.name}</h1>
              <p className="text-xl text-gray-200 font-sans max-w-2xl">{fund.description}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back Button */}
        <div className="mb-8">
          <Link href="/investments" className="inline-flex items-center text-vgreen-primary hover:text-vgreen-secondary font-medium">
            <i className="fas fa-arrow-left mr-2"></i>
            Quay lại danh sách quỹ
          </Link>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">{fund.dailyReturn}%</div>
            <div className="text-sm text-gray-700">Lợi nhuận mỗi ngày</div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">{fund.duration}</div>
            <div className="text-sm text-gray-700">Ngày đầu tư</div>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">{totalReturn}%</div>
            <div className="text-sm text-gray-700">Tổng lợi nhuận</div>
          </div>
          <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl p-6 text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">{fund.progress}%</div>
            <div className="text-sm text-gray-700">Tiến độ hoàn thành</div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Project Overview */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                <i className="fas fa-info-circle text-vgreen-primary mr-3"></i>
                Tổng quan dự án
              </h2>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-gray-100">
                  <span className="text-gray-600">Quy mô dự án</span>
                  <span className="font-semibold">{fund.projectScale}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-100">
                  <span className="text-gray-600">Danh mục quỹ</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(fund.category)}`}>
                    {fund.category}
                  </span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-100">
                  <span className="text-gray-600">Mã quỹ</span>
                  <span className="bg-vgreen-primary text-white px-3 py-1 rounded-lg text-sm font-bold">
                    {fund.code}
                  </span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-100">
                  <span className="text-gray-600">Lợi nhuận dự kiến/năm</span>
                  <span className="font-semibold text-green-600">
                    {(parseFloat(fund.dailyReturn) * 365).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>

            {/* Investment Features */}
            {fund.features && fund.features.length > 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">
                  <i className="fas fa-star text-vgreen-primary mr-3"></i>
                  Đặc điểm nổi bật
                </h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {fund.features.map((feature, index) => (
                    <div key={index} className="flex items-center bg-gray-50 rounded-lg p-4">
                      <div className="w-8 h-8 bg-vgreen-primary rounded-full flex items-center justify-center mr-3">
                        <i className="fas fa-check text-white text-sm"></i>
                      </div>
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Investment Calculator */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                <i className="fas fa-calculator text-vgreen-primary mr-3"></i>
                Tính toán lợi nhuận
              </h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Số tiền đầu tư (VNĐ)
                  </label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-vgreen-primary focus:border-transparent"
                    defaultValue={fund.minInvestment}
                    placeholder="Nhập số tiền đầu tư"
                  />
                </div>
                <div className="grid md:grid-cols-3 gap-4 bg-gray-50 rounded-lg p-4">
                  <div className="text-center">
                    <div className="text-lg font-bold text-gray-900">Hàng ngày</div>
                    <div className="text-sm text-gray-600">+{fund.dailyReturn}%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-gray-900">Hàng tháng</div>
                    <div className="text-sm text-gray-600">+{(parseFloat(fund.dailyReturn) * 30).toFixed(1)}%</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-gray-900">Tổng cộng</div>
                    <div className="text-sm text-gray-600">+{totalReturn}%</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Investment Action */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Đầu tư ngay</h3>
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Số tiền tối thiểu</div>
                  <div className="text-xl font-bold text-vgreen-primary">{fund.minInvestment}</div>
                </div>
                {fund.maxInvestment && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600 mb-1">Số tiền tối đa</div>
                    <div className="text-xl font-bold text-red-600">{fund.maxInvestment}</div>
                  </div>
                )}
                <button 
                  onClick={() => setIsModalOpen(true)}
                  className="w-full bg-gradient-to-r from-vgreen-primary to-success text-white py-4 rounded-xl font-bold text-lg hover:shadow-lg transition-all duration-300"
                >
                  <i className="fas fa-plus mr-2"></i>
                  Đầu tư ngay
                </button>
                <button className="w-full border-2 border-vgreen-primary text-vgreen-primary py-3 rounded-xl font-semibold hover:bg-vgreen-primary hover:text-white transition-all duration-300">
                  <i className="fas fa-heart mr-2"></i>
                  Thêm vào yêu thích
                </button>
              </div>
            </div>

            {/* Progress Tracker */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Tiến độ dự án</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600">Hoàn thành</span>
                    <span className="font-semibold">{fund.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="bg-gradient-to-r from-vgreen-primary to-success h-3 rounded-full transition-all duration-500" 
                      style={{width: `${fund.progress}%`}}
                    ></div>
                  </div>
                </div>
                <div className="pt-4 border-t border-gray-100">
                  <div className="text-sm text-gray-600 mb-2">Thời gian còn lại</div>
                  <div className="text-lg font-bold text-gray-900">
                    {fund.duration - Math.floor(fund.progress / 100 * fund.duration)} ngày
                  </div>
                </div>
              </div>
            </div>

            {/* Risk Warning */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6">
              <div className="flex items-start">
                <i className="fas fa-exclamation-triangle text-yellow-600 text-xl mr-3 mt-1"></i>
                <div>
                  <h4 className="font-semibold text-yellow-800 mb-2">Cảnh báo rủi ro</h4>
                  <p className="text-sm text-yellow-700">
                    Đầu tư có rủi ro. Lợi nhuận trong quá khứ không đảm bảo cho kết quả tương lai. 
                    Vui lòng đọc kỹ thông tin và đánh giá khả năng tài chính trước khi đầu tư.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom padding for mobile navigation */}
      <div className="pb-20 md:pb-0"></div>

      {/* Investment Modal */}
      {fund && (
        <InvestmentModal
          fund={fund}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </div>
  );
}