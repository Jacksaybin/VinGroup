export default function HeroSection() {
  return (
    <section id="dashboard" className="relative gradient-bg text-white overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-20"></div>
      <div className="absolute inset-0 bg-cover bg-center opacity-30" 
           style={{backgroundImage: "url('https://pixabay.com/get/g578c7978ddb7a958dbb1b7bb4ebbe47662e65591316976fa4608d1b1c609c0f7532350dc363be8d945cd1d471f35dcebbc6d4918d46d44a9b9fe364f2ed783f6_1280.jpg')"}}></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight font-sans">
              Đầu Tư Thông Minh<br />
              <span className="text-lime-light">Tương Lai Xanh</span>
            </h1>
            <p className="text-xl mb-8 text-gray-200 leading-relaxed">
              Tham gia đầu tư vào mạng lưới trạm sạc VinFast với lợi nhuận hấp dẫn từ 0.2% - 2.2% mỗi ngày. 
              Xây dựng tương lai bền vững cho Việt Nam.
            </p>
            
            {/* Enhanced Statistics */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-lime-light">150+</div>
                <div className="text-sm text-gray-300">Trạm Sạc</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-lime-light">25K+</div>
                <div className="text-sm text-gray-300">Nhà Đầu Tư</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-lime-light">₫2.5T</div>
                <div className="text-sm text-gray-300">Tổng Đầu Tư</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-white text-vgreen-primary px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-all duration-300 transform hover:scale-105">
                <i className="fas fa-chart-line mr-2"></i>
                Bắt Đầu Đầu Tư
              </button>
              <button className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-vgreen-primary transition-all duration-300">
                <i className="fas fa-play mr-2"></i>
                Xem Demo
              </button>
            </div>
          </div>

          {/* Enhanced Portfolio Summary Card */}
          <div className="glass-effect rounded-2xl p-8 animate-float">
            <h3 className="text-2xl font-bold mb-6">Dashboard Đầu Tư</h3>
            
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Tổng Số Dư:</span>
                <span className="text-2xl font-bold text-vgreen-accent">₫125.750.000</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Lợi Nhuận Hôm Nay:</span>
                <span className="text-xl font-bold text-success">+₫1.250.000</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-gray-300">Quỹ Đang Đầu Tư:</span>
                <span className="text-lg font-semibold">VIC09, VIC05</span>
              </div>
              
              {/* Mini Chart Placeholder */}
              <div className="bg-white bg-opacity-10 rounded-lg p-4">
                <div className="flex items-end space-x-2 h-16">
                  <div className="bg-vgreen-accent w-3 h-8 rounded-t"></div>
                  <div className="bg-success w-3 h-12 rounded-t"></div>
                  <div className="bg-vgreen-accent w-3 h-6 rounded-t"></div>
                  <div className="bg-success w-3 h-16 rounded-t"></div>
                  <div className="bg-vgreen-accent w-3 h-10 rounded-t"></div>
                  <div className="bg-success w-3 h-14 rounded-t"></div>
                  <div className="bg-vgreen-accent w-3 h-12 rounded-t"></div>
                </div>
                <p className="text-xs text-gray-300 mt-2">Biểu đồ lợi nhuận 7 ngày</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
