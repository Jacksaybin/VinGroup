export default function Header() {
  return (
    <header className="sticky top-0 z-50 glass-effect">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo Section */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-vgreen-primary to-vgreen-accent rounded-lg flex items-center justify-center shadow-lg">
              <i className="fas fa-leaf text-white text-lg"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold text-vgreen-primary">VGreen</h1>
              <p className="text-xs text-gray-600 hidden sm:block">VinFast Investment Platform</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#dashboard" className="text-gray-700 hover:text-vgreen-primary transition-colors">Dashboard</a>
            <a href="#investments" className="text-gray-700 hover:text-vgreen-primary transition-colors">Đầu Tư</a>
            <a href="#analytics" className="text-gray-700 hover:text-vgreen-primary transition-colors">Phân Tích</a>
            <a href="#news" className="text-gray-700 hover:text-vgreen-primary transition-colors">Tin Tức</a>
            <a href="#support" className="text-gray-700 hover:text-vgreen-primary transition-colors">Hỗ Trợ</a>
          </nav>

          {/* User Actions */}
          <div className="flex items-center space-x-4">
            <button className="relative p-2 text-gray-600 hover:text-vgreen-primary">
              <i className="fas fa-bell"></i>
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-vinfast-red text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-vgreen-primary to-vgreen-accent rounded-full flex items-center justify-center shadow-md">
                <i className="fas fa-user text-white text-sm"></i>
              </div>
              <span className="hidden sm:block text-sm font-medium">Nguyễn Văn An</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
