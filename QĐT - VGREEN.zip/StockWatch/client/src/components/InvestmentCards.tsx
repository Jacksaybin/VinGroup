import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type InvestmentFund } from "@shared/schema";
import { Link } from "wouter";
import InvestmentModal from "./InvestmentModal";

export default function InvestmentCards() {
  const [selectedFund, setSelectedFund] = useState<InvestmentFund | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { data: funds = [], isLoading } = useQuery<InvestmentFund[]>({
    queryKey: ["/api/investment-funds"],
  });

  // Show first 6 funds for homepage preview
  const featuredFunds = funds.slice(0, 6);

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "Cơ Bản": "from-blue-500 to-blue-600",
      "Đặc Biệt": "from-purple-500 to-purple-600",
      "Thường": "from-green-500 to-emerald-600",
      "VIP": "from-yellow-500 to-orange-600",
      "Cao Cấp": "from-indigo-500 to-indigo-600",
      "Premium": "from-pink-500 to-pink-600",
      "VIC": "from-orange-500 to-orange-600",
      "VIC Premium": "from-red-500 to-red-600",
      "VIC Elite": "from-emerald-500 to-emerald-600",
      "VIC Ultimate": "from-violet-500 to-violet-600",
      "VIC Future": "from-rose-500 to-rose-600"
    };
    return colors[category] || "from-gray-500 to-gray-600";
  };

  if (isLoading) {
    return (
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-vgreen-primary mx-auto"></div>
            <p className="mt-4 text-gray-600">Đang tải các quỹ đầu tư...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="investments" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold font-sans text-gray-900 mb-4">Cơ Hội Đầu Tư VinFast</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-sans">
            Khám phá các gói đầu tư trạm sạc VinFast với mức lợi nhuận hấp dẫn và thời gian đầu tư linh hoạt
          </p>
          
          {/* Investment Filter Tabs */}
          <div className="flex justify-center mt-8">
            <div className="bg-gray-100 p-1 rounded-xl flex">
              <Link href="/investments" className="px-6 py-3 rounded-lg bg-vgreen-primary text-white font-medium">Xem Tất Cả 14 Quỹ</Link>
              <button className="px-6 py-3 rounded-lg text-gray-600 hover:text-vgreen-primary">Cơ Bản</button>
              <button className="px-6 py-3 rounded-lg text-gray-600 hover:text-vgreen-primary">Cao Cấp</button>
              <button className="px-6 py-3 rounded-lg text-gray-600 hover:text-vgreen-primary">VIP</button>
            </div>
          </div>
        </div>

        {/* Dynamic Investment Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredFunds.map((fund) => (
            <div key={fund.id} className="card-hover bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">
              <div className={`h-48 bg-gradient-to-br ${getCategoryColor(fund.category)} relative overflow-hidden`}>
                <img 
                  src={fund.image} 
                  alt={fund.name}
                  className="w-full h-full object-cover opacity-80" 
                />
                <div className="absolute inset-0 bg-black bg-opacity-20"></div>
                <div className="absolute top-4 right-4 bg-white bg-opacity-20 backdrop-blur-sm rounded-lg p-2">
                  <i className="fas fa-charging-station text-white text-lg"></i>
                </div>
                <div className="absolute top-4 left-4 bg-white bg-opacity-90 rounded-lg px-3 py-1">
                  <span className="text-sm font-bold text-gray-900">{fund.code}</span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{fund.name}</h3>
                <p className="text-gray-600 text-sm mb-4">{fund.description}</p>
                
                <div className="grid grid-cols-3 gap-3 mb-6">
                  <div className="text-center bg-green-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-green-600">{fund.dailyReturn}%</div>
                    <div className="text-xs text-gray-600">Lợi nhuận/ngày</div>
                  </div>
                  <div className="text-center bg-blue-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-blue-600">{fund.duration}</div>
                    <div className="text-xs text-gray-600">Ngày</div>
                  </div>
                  <div className="text-center bg-purple-50 rounded-lg p-3">
                    <div className="text-lg font-bold text-purple-600">{fund.minInvestment}</div>
                    <div className="text-xs text-gray-600">Tối thiểu</div>
                  </div>
                </div>

                <div className="flex space-x-2 mb-4">
                  <Link 
                    href={`/fund/${fund.id}`}
                    className="flex-1 bg-white border-2 border-vgreen-primary text-vgreen-primary py-3 rounded-xl font-semibold hover:bg-vgreen-primary hover:text-white transition-all duration-300 text-center"
                  >
                    <i className="fas fa-eye mr-2"></i>
                    Chi Tiết
                  </Link>
                  <button 
                    onClick={() => {
                      setSelectedFund(fund);
                      setIsModalOpen(true);
                    }}
                    className={`flex-1 bg-gradient-to-r ${getCategoryColor(fund.category)} text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-300`}
                  >
                    <i className="fas fa-plus mr-2"></i>
                    Đầu Tư
                  </button>
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600">Tiến độ dự án</span>
                    <span className="font-semibold">{fund.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`bg-gradient-to-r ${getCategoryColor(fund.category)} h-2 rounded-full transition-all duration-300`} 
                      style={{width: `${fund.progress}%`}}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <Link 
            href="/investments"
            className="inline-flex items-center bg-gradient-to-r from-vgreen-primary to-success text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-xl transition-all duration-300"
          >
            <i className="fas fa-chart-line mr-3"></i>
            Xem Tất Cả {funds.length} Quỹ Đầu Tư
            <i className="fas fa-arrow-right ml-3"></i>
          </Link>
        </div>
      </div>

      {/* Investment Modal */}
      {selectedFund && (
        <InvestmentModal
          fund={selectedFund}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setSelectedFund(null);
          }}
        />
      )}
    </section>
  );
}