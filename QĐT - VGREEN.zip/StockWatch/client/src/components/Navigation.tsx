import { Link, useLocation } from "wouter";

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { 
      path: "/", 
      label: "Trang Chủ", 
      icon: "fas fa-home",
      description: "Dashboard chính"
    },
    { 
      path: "/investments", 
      label: "Đầu Tư", 
      icon: "fas fa-chart-line",
      description: "14 quỹ đầu tư"
    },
    { 
      path: "/news", 
      label: "Tin Tức", 
      icon: "fas fa-newspaper",
      description: "Cập nhật mới nhất"
    },
    { 
      path: "/profile", 
      label: "Hồ Sơ", 
      icon: "fas fa-user",
      description: "Thông tin cá nhân"
    },
    { 
      path: "/support", 
      label: "Hỗ Trợ", 
      icon: "fas fa-headset",
      description: "Trợ giúp khách hàng"
    }
  ];

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:block bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-vgreen-primary to-success rounded-lg flex items-center justify-center">
                <i className="fas fa-leaf text-white text-lg"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold text-vgreen-primary">VGreen</h1>
                <p className="text-xs text-gray-600">VinFast Investment Platform</p>
              </div>
            </Link>

            {/* Navigation Links */}
            <div className="flex space-x-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  href={item.path}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
                    location === item.path
                      ? "bg-vgreen-primary text-white"
                      : "text-gray-700 hover:text-vgreen-primary hover:bg-gray-50"
                  }`}
                >
                  <i className={item.icon}></i>
                  <span>{item.label}</span>
                </Link>
              ))}
            </div>

            {/* User Actions */}
            <div className="flex items-center space-x-4">
              <button className="relative p-2 text-gray-600 hover:text-vgreen-primary transition-colors">
                <i className="fas fa-bell"></i>
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-vinfast-red text-white text-xs rounded-full flex items-center justify-center">3</span>
              </button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-vgreen-primary to-success rounded-full flex items-center justify-center">
                  <i className="fas fa-user text-white text-sm"></i>
                </div>
                <span className="text-sm font-medium">Nguyễn Văn An</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation - Bottom Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-50">
        <div className="grid grid-cols-4 h-16">
          {navItems.slice(0, 4).map((item) => (
            <Link
              key={item.path}
              href={item.path}
              className={`flex flex-col items-center justify-center transition-colors ${
                location === item.path
                  ? "text-vgreen-primary"
                  : "text-gray-500 hover:text-vgreen-primary"
              }`}
            >
              <i className={`${item.icon} text-lg mb-1`}></i>
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          ))}
        </div>
      </nav>

      {/* Mobile Header */}
      <header className="md:hidden bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-vgreen-primary to-success rounded-lg flex items-center justify-center">
                <i className="fas fa-leaf text-white text-sm"></i>
              </div>
              <div>
                <h1 className="text-lg font-bold text-vgreen-primary">VGreen</h1>
              </div>
            </Link>

            <div className="flex items-center space-x-3">
              <button className="relative p-2 text-gray-600 hover:text-vgreen-primary">
                <i className="fas fa-bell"></i>
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-vinfast-red text-white text-xs rounded-full flex items-center justify-center">3</span>
              </button>
              <div className="w-8 h-8 bg-gradient-to-r from-vgreen-primary to-success rounded-full flex items-center justify-center">
                <i className="fas fa-user text-white text-sm"></i>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb Navigation */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center space-x-2 text-sm">
            <Link href="/" className="text-gray-500 hover:text-vgreen-primary">
              <i className="fas fa-home mr-1"></i>
              Trang Chủ
            </Link>
            {location !== "/" && (
              <>
                <i className="fas fa-chevron-right text-gray-300"></i>
                <span className="text-vgreen-primary font-medium">
                  {navItems.find(item => item.path === location)?.label || "Trang Hiện Tại"}
                </span>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}