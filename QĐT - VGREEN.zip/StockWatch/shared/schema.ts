import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const investmentFunds = pgTable("investment_funds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  dailyReturn: decimal("daily_return", { precision: 5, scale: 3 }).notNull(),
  duration: integer("duration").notNull(),
  minInvestment: text("min_investment").notNull(),
  maxInvestment: text("max_investment"),
  projectScale: text("project_scale").notNull(),
  progress: integer("progress").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  features: text("features").array(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertInvestmentFundSchema = createInsertSchema(investmentFunds).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertInvestmentFund = z.infer<typeof insertInvestmentFundSchema>;
export type InvestmentFund = typeof investmentFunds.$inferSelect;
