import { type User, type InsertUser, type InvestmentFund, type InsertInvestmentFund } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllInvestmentFunds(): Promise<InvestmentFund[]>;
  getInvestmentFund(id: string): Promise<InvestmentFund | undefined>;
  createInvestmentFund(fund: InsertInvestmentFund): Promise<InvestmentFund>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private investmentFunds: Map<string, InvestmentFund>;

  constructor() {
    this.users = new Map();
    this.investmentFunds = new Map();
    this.initializeInvestmentFunds();
  }

  private initializeInvestmentFunds() {
    const funds: Omit<InvestmentFund, 'id'>[] = [
      {
        name: "DC 60kW Charging Station",
        code: "DC60",
        dailyReturn: "0.2",
        duration: 30,
        minInvestment: "50.000.000 VNĐ",
        maxInvestment: "500.000.000 VNĐ",
        projectScale: "100 trạm sạc",
        progress: 85,
        category: "Cơ Bản",
        description: "Đầu tư vào hệ thống trạm sạc DC 60kW cho xe điện VinFast",
        image: "https://images.unsplash.com/photo-1593941707882-a5bac6861d75?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Công suất 60kW", "Thời gian sạc nhanh", "Tích hợp VinGroup"]
      },
      {
        name: "VinGroup Loyalty Card Fund",
        code: "VGC",
        dailyReturn: "0.25",
        duration: 45,
        minInvestment: "150.000.000 VNĐ",
        maxInvestment: "1.000.000.000 VNĐ",
        projectScale: "Toàn quốc",
        progress: 78,
        category: "Đặc Biệt",
        description: "Quỹ phát triển hệ thống thẻ tích lũy VinGroup tích hợp với VinFast",
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Tích hợp VinGroup", "Ưu đãi đặc biệt", "Phần thưởng tích lũy"]
      },
      {
        name: "Regular Charging Package",
        code: "RCP",
        dailyReturn: "0.3",
        duration: 45,
        minInvestment: "300.000.000 VNĐ",
        maxInvestment: "2.000.000.000 VNĐ",
        projectScale: "150 trạm sạc",
        progress: 92,
        category: "Thường",
        description: "Gói đầu tư trạm sạc VinFast dành cho người dùng phổ thông",
        image: "https://pixabay.com/get/gd1c49a15071177388414a65175eae13e6e5854538c683ff9e9345f3d55d0018754f558935ad9696aed5cc6df8a463679d0ed4c807736cc2e814f0045d6bb7fd8_1280.jpg",
        features: ["Phù hợp mọi người", "Lợi nhuận ổn định", "Thời gian linh hoạt"]
      },
      {
        name: "VIP Investment Package",
        code: "VIP",
        dailyReturn: "0.35",
        duration: 60,
        minInvestment: "500.000.000 VNĐ",
        maxInvestment: "5.000.000.000 VNĐ",
        projectScale: "200 trạm sạc",
        progress: 65,
        category: "VIP",
        description: "Gói đầu tư VIP với lợi nhuận cao và ưu tiên hàng đầu",
        image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Lợi nhuận cao", "Ưu tiên VIP", "Hỗ trợ 24/7"]
      },
      {
        name: "DC 80kW High Power",
        code: "DC80",
        dailyReturn: "0.5",
        duration: 90,
        minInvestment: "1.000.000.000 VNĐ",
        maxInvestment: "10.000.000.000 VNĐ",
        projectScale: "80 trạm sạc",
        progress: 70,
        category: "Cao Cấp",
        description: "Hệ thống trạm sạc DC 80kW công suất cao cho VinFast",
        image: "https://images.unsplash.com/photo-1593941707882-a5bac6861d75?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Công suất 80kW", "Sạc siêu nhanh", "Công nghệ tiên tiến"]
      },
      {
        name: "DC 120kW Ultra Fast",
        code: "DC120",
        dailyReturn: "0.6",
        duration: 90,
        minInvestment: "2.000.000.000 VNĐ",
        maxInvestment: "20.000.000.000 VNĐ",
        projectScale: "60 trạm sạc",
        progress: 58,
        category: "Cao Cấp",
        description: "Trạm sạc siêu nhanh DC 120kW cho xe điện VinFast",
        image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["120kW siêu nhanh", "Tương lai công nghệ", "Hiệu suất cao"]
      },
      {
        name: "DC 150kW Premium",
        code: "DC150",
        dailyReturn: "0.7",
        duration: 100,
        minInvestment: "3.000.000.000 VNĐ",
        maxInvestment: "30.000.000.000 VNĐ",
        projectScale: "40 trạm sạc",
        progress: 45,
        category: "Premium",
        description: "Hệ thống trạm sạc DC 150kW premium cho VinFast",
        image: "https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["150kW premium", "Công nghệ đỉnh cao", "Đầu tư cao cấp"]
      },
      {
        name: "3D 300kW Revolution",
        code: "3D300",
        dailyReturn: "0.8",
        duration: 180,
        minInvestment: "5.000.000.000 VNĐ",
        maxInvestment: "50.000.000.000 VNĐ",
        projectScale: "25 trạm sạc",
        progress: 30,
        category: "Premium",
        description: "Công nghệ sạc 3D 300kW cách mạng cho tương lai",
        image: "https://images.unsplash.com/photo-1593941707882-a5bac6861d75?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Công nghệ 3D", "300kW cách mạng", "Tương lai xa"]
      },
      {
        name: "VIC01 Infrastructure",
        code: "VIC01",
        dailyReturn: "1.0",
        duration: 180,
        minInvestment: "10.000.000.000 VNĐ",
        maxInvestment: "100.000.000.000 VNĐ",
        projectScale: "Cơ sở hạ tầng",
        progress: 75,
        category: "VIC",
        description: "Quỹ phát triển cơ sở hạ tầng trạm sạc VinFast toàn diện",
        image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Hạ tầng toàn diện", "Quy mô lớn", "Đầu tư dài hạn"]
      },
      {
        name: "VIC03 Smart Network",
        code: "VIC03",
        dailyReturn: "1.2",
        duration: 300,
        minInvestment: "15.000.000.000 VNĐ",
        maxInvestment: "150.000.000.000 VNĐ",
        projectScale: "Mạng lưới thông minh",
        progress: 55,
        category: "VIC",
        description: "Mạng lưới trạm sạc thông minh VinFast với AI",
        image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["AI thông minh", "Mạng lưới kết nối", "Công nghệ 4.0"]
      },
      {
        name: "VIC05 Fast Network",
        code: "VIC05",
        dailyReturn: "1.5",
        duration: 365,
        minInvestment: "25.000.000.000 VNĐ",
        maxInvestment: "250.000.000.000 VNĐ",
        projectScale: "Mạng sạc nhanh",
        progress: 40,
        category: "VIC Premium",
        description: "Mạng lưới sạc nhanh VinFast quy mô toàn quốc",
        image: "https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Sạc nhanh toàn quốc", "Quy mô khủng", "Lợi nhuận cao"]
      },
      {
        name: "VIC07 Elite System",
        code: "VIC07",
        dailyReturn: "1.8",
        duration: 365,
        minInvestment: "50.000.000.000 VNĐ",
        maxInvestment: "500.000.000.000 VNĐ",
        projectScale: "Hệ thống Elite",
        progress: 25,
        category: "VIC Elite",
        description: "Hệ thống trạm sạc Elite cao cấp nhất VinFast",
        image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Elite cao cấp", "Công nghệ đỉnh", "Lợi nhuận tối đa"]
      },
      {
        name: "VIC09 DC Charging",
        code: "VIC09",
        dailyReturn: "2.0",
        duration: 365,
        minInvestment: "75.000.000.000 VNĐ",
        maxInvestment: "750.000.000.000 VNĐ",
        projectScale: "DC Charging Network",
        progress: 15,
        category: "VIC Ultimate",
        description: "Mạng lưới sạc DC cao cấp nhất của VinFast",
        image: "https://images.unsplash.com/photo-1593941707882-a5bac6861d75?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["DC cao cấp", "Mạng lưới rộng", "Lợi nhuận đỉnh cao"]
      },
      {
        name: "VIC11 Future Tech",
        code: "VIC11",
        dailyReturn: "2.2",
        duration: 365,
        minInvestment: "100.000.000.000 VNĐ",
        maxInvestment: "1.000.000.000.000 VNĐ",
        projectScale: "Công nghệ tương lai",
        progress: 10,
        category: "VIC Future",
        description: "Công nghệ sạc tương lai cho thế hệ xe điện mới",
        image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        features: ["Công nghệ tương lai", "Đầu tư khủng", "Lợi nhuận tối ưu"]
      }
    ];

    funds.forEach(fund => {
      const id = randomUUID();
      this.investmentFunds.set(id, { 
        ...fund, 
        id,
        maxInvestment: fund.maxInvestment || null,
        features: fund.features || null
      });
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllInvestmentFunds(): Promise<InvestmentFund[]> {
    return Array.from(this.investmentFunds.values());
  }

  async getInvestmentFund(id: string): Promise<InvestmentFund | undefined> {
    return this.investmentFunds.get(id);
  }

  async createInvestmentFund(insertFund: InsertInvestmentFund): Promise<InvestmentFund> {
    const id = randomUUID();
    const fund: InvestmentFund = { ...insertFund, id };
    this.investmentFunds.set(id, fund);
    return fund;
  }
}

export const storage = new MemStorage();
