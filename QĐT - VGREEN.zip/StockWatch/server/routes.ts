import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Investment funds routes
  app.get("/api/investment-funds", async (req, res) => {
    try {
      const funds = await storage.getAllInvestmentFunds();
      res.json(funds);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch investment funds" });
    }
  });

  app.get("/api/investment-funds/:id", async (req, res) => {
    try {
      const fund = await storage.getInvestmentFund(req.params.id);
      if (!fund) {
        return res.status(404).json({ error: "Investment fund not found" });
      }
      res.json(fund);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch investment fund" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
